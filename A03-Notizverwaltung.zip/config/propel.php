<?php

return [
  'propel' => [
    'database' => [
      'connections' => [
        'notizen' => [
          'adapter'    => 'mysql',
          'classname'  => 'Propel\Runtime\Connection\ConnectionWrappe$
          'dsn'        => 'mysql:host=localhost;dbname=notizverwaltun$
          'user'       => 'notizverwaltung',
          'password'   => 'notizverwaltung',
          'attributes' => []
          ]
          ]
        ],
        'runtime' => [
          'defaultConnection' => 'notizverwaltung',
          'connections' => ['notizverwaltung']
        ],
        'generator' => [
          'defaultConnection' => 'notizverwaltung',
          'connections' => ['notizverwaltung']
        ]
    ]
];
